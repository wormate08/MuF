package com.example.monitoring_and_feedback;
//Authors: Paul Berkemeier, Jannik Hoch, Axel Theiss
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //wird nicht mehr benötigt diese Vorgehensweise
        /*getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.container, new NavigationFragment())
                .commit();*/
    }
}
