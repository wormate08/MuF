package com.example.monitoring_and_feedback;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.monitoring_and_feedback.Data.AccData;
import com.example.monitoring_and_feedback.dao.AccDataDao;

@Database(entities = {AccData.class}, version = 2)
public abstract class MUFDatabase extends RoomDatabase {
    private static MUFDatabase instance;

    public abstract AccDataDao getAccDataDao();

    //Datenbank Instanz returnieren
    public static synchronized MUFDatabase getInstance(Context context){
        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    MUFDatabase.class,"MUF_database").fallbackToDestructiveMigration()
                    .build();
        }return instance;
    }
}
