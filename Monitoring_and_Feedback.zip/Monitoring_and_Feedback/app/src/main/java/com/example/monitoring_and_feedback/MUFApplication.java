package com.example.monitoring_and_feedback;

import android.app.Application;

import androidx.room.Room;

public class MUFApplication extends Application {
    private MUFDatabase mufDatabase;

    //Datenbank anlegen über Room, Name muf7 nur wie im Videobeispiel gewählt, könnte auch anders sein
    @Override
    public void onCreate() {
        super.onCreate();
        mufDatabase = Room.databaseBuilder(this, MUFDatabase.class, "muf7").build();
    }

    public MUFDatabase getMufDatabase(){
        return mufDatabase;
    }
}
