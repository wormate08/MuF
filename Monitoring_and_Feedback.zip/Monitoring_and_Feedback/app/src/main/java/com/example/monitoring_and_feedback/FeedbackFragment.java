package com.example.monitoring_and_feedback;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.monitoring_and_feedback.Data.AccData;
import com.example.monitoring_and_feedback.viewModel.AccViewModel;

public class FeedbackFragment extends Fragment {
    private AccViewModel accViewModel;
    private TextView feedbackTextView;
    private SensorManager sensorManager;
    private Sensor acc_sensor;

    //Eventlistener erstellen
    private SensorEventListener sensorEventListener = new SensorEventListener() {
        // Methoden müssen überschrieben werden
        // Funktion für den Fall dass sich Sensor Daten ändern
        @Override
        public void onSensorChanged(SensorEvent event) {
            // Acc Daten liegen in event.values[0-2]
            float acc_x = event.values[0];
            float acc_y = event.values[1];
            float acc_z = event.values[2];
            //System gibt aktuelle Systemzeit aus, für erstellten Konstruktor
            AccData accData = new AccData(System.currentTimeMillis(),acc_x,acc_y,acc_z);
            //Ausgabe
            feedbackTextView.setText(String.format("x-axis: %f\ny-axis: %f\nz-axis: %f",acc_x,acc_y,acc_z));
           //Eintrag der Daten im ViewModel
            accViewModel.insert(accData);
        }
        // Muss überschrieben werden, aber FUnktionalität nicht benötigt, daher leer
        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
         feedbackTextView = view.findViewById(R.id.sensoryFeedback);
        // Funktionalität für den Button um zur Navigation zu kommen
        final NavController controller = Navigation.findNavController(view);
        view.findViewById(R.id.buttonFeedNav).setOnClickListener(buttonFeedNav -> {
            controller.navigate(FeedbackFragmentDirections.actionFeedbackFragmentToNavigationFragment());
        });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        accViewModel = new ViewModelProvider(getActivity()).get(AccViewModel.class);
        View v = inflater.inflate(R.layout.fragment_feedback, container, false);
        //Sensor Manager instanzieren, um Zugriff auf Acc Sensor zu erhalten
        sensorManager = (SensorManager) getActivity().getSystemService(Context.SENSOR_SERVICE);
        acc_sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        accViewModel = new ViewModelProvider(this).get(AccViewModel.class);
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        sensorManager.registerListener(sensorEventListener, acc_sensor, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    public void onPause() {
        super.onPause();
        sensorManager.unregisterListener(sensorEventListener);
    }
}
