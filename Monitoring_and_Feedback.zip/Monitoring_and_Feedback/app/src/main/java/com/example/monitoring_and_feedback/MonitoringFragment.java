package com.example.monitoring_and_feedback;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.monitoring_and_feedback.Data.AccData;
import com.example.monitoring_and_feedback.Data.AccDataAdapter;
import com.example.monitoring_and_feedback.viewModel.AccViewModel;

import java.util.List;

public class MonitoringFragment extends Fragment {
    private AccViewModel accViewModel;
    private AccDataAdapter adapter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //Entsprechendes Layout inflaten
        View v = inflater.inflate(R.layout.fragment_monitoring,container, false);;




        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        accViewModel = new ViewModelProvider(
                getActivity(),
                (ViewModelProvider.Factory) ViewModelProvider.AndroidViewModelFactory.getInstance(getActivity().getApplication())
        ).get(AccViewModel.class);
        //RecyclerView anlegen, Adapter zuteilen und observer draufsetzen
        RecyclerView recyclerView = view.findViewById(R.id.monitoringRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setHasFixedSize(true);
        adapter = new AccDataAdapter();
        recyclerView.setAdapter(adapter);
        AccViewModel accViewModel= new ViewModelProvider(this).get(AccViewModel.class);
        accViewModel.getListAccData().observe(getViewLifecycleOwner(), accData -> {
            adapter.setAccDataList(accData);
        });

        //Funktionalität für Button zur Navigation
        final NavController controller = Navigation.findNavController(view);
        view.findViewById(R.id.buttonMonNav).setOnClickListener(buttonMonNav -> {
            controller.navigate(MonitoringFragmentDirections.actionMonitoringFragmentToNavigationFragment());
        });
    }
}
