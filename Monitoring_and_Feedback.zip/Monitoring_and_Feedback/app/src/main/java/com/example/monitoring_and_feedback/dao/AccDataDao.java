package com.example.monitoring_and_feedback.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.monitoring_and_feedback.Data.AccData;

import java.util.List;

@Dao
abstract public class AccDataDao {
//Query zur Abfrage der Datensätze aus der Datenbank
    @Query("SELECT * FROM accdata order by id desc")
    public abstract LiveData<List<AccData>> getAccData();

    // Insert zum Einfügen eines neuen Datensatzes, bei selbem Primary Key REPLACE
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public abstract long insert(AccData accData);
}
