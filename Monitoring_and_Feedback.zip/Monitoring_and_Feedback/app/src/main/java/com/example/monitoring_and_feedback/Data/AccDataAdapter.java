package com.example.monitoring_and_feedback.Data;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.monitoring_and_feedback.R;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
// eigener Adapter gemäß Anforderungen, leitet von RecyclerView Adapter an
public class AccDataAdapter extends RecyclerView.Adapter<AccDataAdapter.AccDataViewHolder>{

    private List<AccData> accDataList = new ArrayList<>();
    // on create den View inflaten und einen ViewHolder returnen
    @NonNull
    @Override
    public AccDataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.accdata_layout, parent, false);
        return new AccDataViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AccDataViewHolder holder, int position) {
        AccData accData = accDataList.get(position);
        //Format für die spätere Anzeige, hier 3 Nachkommastellen
        DecimalFormat decimalFormat = new DecimalFormat("#.###");
        // %-Operator um den Timestamp zu kürzen, hier jetzt 1000 s Spannbreite der Werte
        // Wenn mehr gewünscht ist, diesen Schritt evtl. weglassen
        //Dient nur der besseren Anzeige in diesem Beispiel
        String time = decimalFormat.format(accData.getTimestamp()%1000000);
        String x = decimalFormat.format(accData.getAcc_x());
        String y = decimalFormat.format(accData.getAcc_y());
        String z = decimalFormat.format(accData.getAcc_z());

        //Durch Formating keine Umwandlung mehr zu String notwendig
        //holder.textViewAccDataTime.setText(String.valueOf(accData.getTimestamp()));
        //holder.textViewAccDataX.setText(String.valueOf(accData.getAcc_x()));
        //holder.textViewAccDataY.setText(String.valueOf(accData.getAcc_y()));
        //holder.textViewAccDataZ.setText(String.valueOf(accData.getAcc_z()));
        holder.textViewAccDataTime.setText(time);
        holder.textViewAccDataX.setText(x);
        holder.textViewAccDataY.setText(y);
        holder.textViewAccDataZ.setText(z);
    }
    //Einfache Rückgabe der Listenlänge
    @Override
    public int getItemCount() {
        return accDataList.size();
    }

    //Liste wird gesetzt über übergebene Liste
    public void setAccDataList(List<AccData> accDataList){

        this.accDataList = accDataList;
        //Wichtig zur Kommunikation, dass sich die Liste geändert hat
        notifyDataSetChanged();
    }

    static class AccDataViewHolder extends RecyclerView.ViewHolder{
        private TextView textViewAccDataTime;
        private TextView textViewAccDataX;
        private TextView textViewAccDataY;
        private TextView textViewAccDataZ;

        //Hier wird nur Konstruktor benötigt
        public AccDataViewHolder(@NonNull View itemView) {
            super(itemView);
            //Verweise auf accdata_Layout textViews
            textViewAccDataTime = itemView.findViewById(R.id.textViewAccDataTime);
            textViewAccDataX = itemView.findViewById(R.id.textViewAccDataX);
            textViewAccDataY = itemView.findViewById(R.id.textViewAccDataY);
            textViewAccDataZ = itemView.findViewById(R.id.textViewAccDataZ);
        }
    }
}
