package com.example.monitoring_and_feedback.viewModel;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;

import com.example.monitoring_and_feedback.Data.AccData;
import com.example.monitoring_and_feedback.MUFDatabase;
import com.example.monitoring_and_feedback.dao.AccDataDao;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class AccViewModel extends BaseViewModel {
    private AccDataDao accDataDao;
    private LiveData<List<AccData>> listAccData;
    private ExecutorService executorService;

    public AccViewModel(@NonNull Application application) {
        super(application);
        //Datenbank instanzieren
        MUFDatabase mufDatabase = MUFDatabase.getInstance(application);
        //Dao instanzieren
        accDataDao = mufDatabase.getAccDataDao();
        listAccData = accDataDao.getAccData();
        //Exekutor erstellen
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<AccData>> getListAccData(){
        return listAccData;
    }

    public void insert(AccData accData){
        //Exekutor ruft Dao Methode Insert auf
        executorService.execute(()->
                accDataDao.insert(accData)
        );
    }
}
