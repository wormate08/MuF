package com.example.monitoring_and_feedback;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.monitoring_and_feedback.viewModel.AccViewModel;

public class NavigationFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //Layout Inflaten
        View v = inflater.inflate(R.layout.fragment_navigation,container, false);

        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        // Funktionalität für die beiden Buttons zu Monitoring und Feedback
        final NavController controller = Navigation.findNavController(view);
        view.findViewById(R.id.buttonMonNav).setOnClickListener(buttonNavMon -> {
           controller.navigate(NavigationFragmentDirections.actionNavigationFragmentToMonitoringFragment3());
        });
        view.findViewById(R.id.buttonNavFeed).setOnClickListener(buttonNavFeed -> {
            controller.navigate(NavigationFragmentDirections.actionNavigationFragmentToFeedbackFragment());
        });
    }
}
